// lib/accessibility_screen.dart
import 'package:flutter/material.dart';
import 'drawer_screens.dart';

class AccessibilityScreen extends StatelessWidget {
  const AccessibilityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Accessibility'),
        centerTitle: true,
      ),
      drawer: const AppDrawer(),
      body: Center(
        child: const Text(
          'Accessibility settings coming soon!',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
