// lib/main.dart
// ignore_for_file: unused_local_variable, unused_import

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models/habit.dart';
import 'providers/habits_provider.dart';
import 'providers/notes_provider.dart';
import 'providers/journal_provider.dart';
import 'drawer_screens.dart';
import 'add_habit_screen.dart';
import 'progress_statistics_screen.dart';
import 'calendar_view_screen.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeNotifier()),
        ChangeNotifierProvider(create: (_) => HabitsProvider()),
        ChangeNotifierProvider(create: (_) => NotesProvider()),
        ChangeNotifierProvider(create: (_) => JournalProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class ThemeNotifier extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.light;

  ThemeMode get themeMode => _themeMode;

  void toggleTheme(bool isDarkMode) {
    _themeMode = isDarkMode ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeNotifier = Provider.of<ThemeNotifier>(context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Habit Tracker',
      theme: ThemeData.light().copyWith(
        primaryColor: Colors.teal,
        textTheme: const TextTheme(
          bodyMedium: TextStyle(fontSize: 18),
        ),
        colorScheme: const ColorScheme.light(
          primary: Colors.teal,
          secondary: Colors.tealAccent,
        ).copyWith(background: Colors.teal),
      ),
      darkTheme: ThemeData.dark().copyWith(
        primaryColor: Colors.teal,
        colorScheme: const ColorScheme.dark(
          primary: Colors.teal,
          secondary: Colors.tealAccent,
        ),
        checkboxTheme: CheckboxThemeData(
          fillColor: MaterialStateProperty.resolveWith<Color?>(
              (Set<MaterialState> states) {
            if (states.contains(MaterialState.disabled)) {
              return null;
            }
            if (states.contains(MaterialState.selected)) {
              return Colors.tealAccent;
            }
            return null;
          }),
        ),
        radioTheme: RadioThemeData(
          fillColor: MaterialStateProperty.resolveWith<Color?>(
              (Set<MaterialState> states) {
            if (states.contains(MaterialState.disabled)) {
              return null;
            }
            if (states.contains(MaterialState.selected)) {
              return Colors.tealAccent;
            }
            return null;
          }),
        ),
        switchTheme: SwitchThemeData(
          thumbColor: MaterialStateProperty.resolveWith<Color?>(
              (Set<MaterialState> states) {
            if (states.contains(MaterialState.disabled)) {
              return null;
            }
            if (states.contains(MaterialState.selected)) {
              return Colors.tealAccent;
            }
            return null;
          }),
          trackColor: MaterialStateProperty.resolveWith<Color?>(
              (Set<MaterialState> states) {
            if (states.contains(MaterialState.disabled)) {
              return null;
            }
            if (states.contains(MaterialState.selected)) {
              return Colors.tealAccent;
            }
            return null;
          }),
        ),
      ),
      themeMode: themeNotifier.themeMode,
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  HomeScreenState createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>();

  @override
  Widget build(BuildContext context) {
    final themeNotifier = Provider.of<ThemeNotifier>(context);
    final habitsProvider = Provider.of<HabitsProvider>(context);
    final habits = habitsProvider.habits;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Habit Tracker"),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep),
            tooltip: 'Delete Completed Habits',
            onPressed: () {
              habitsProvider.deleteCompletedHabits();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Completed habits deleted.'),
                ),
              );
            },
          ),
        ],
      ),
      drawer: const AppDrawer(), // Use the centralized AppDrawer
      body: habits.isEmpty
          ? Center(
              child: Text(
                "No habits added yet!",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey[600],
                ),
              ),
            )
          : AnimatedList(
              key: _listKey,
              initialItemCount: habits.length,
              padding: const EdgeInsets.all(8.0),
              itemBuilder: (context, index, animation) {
                return _buildHabitItem(habits[index], index, animation);
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newHabit = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddHabitScreen()),
          );
          if (newHabit != null && newHabit is String) {
            habitsProvider.addHabit(newHabit);
            _listKey.currentState?.insertItem(0);
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildHabitItem(Habit habit, int index, Animation<double> animation) {
    return SizeTransition(
      sizeFactor: animation,
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 6.0),
        elevation: 2,
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor:
                habit.isCompleted ? Colors.green : Colors.redAccent,
            child: Icon(
              habit.isCompleted ? Icons.check : Icons.close,
              color: Colors.white,
            ),
          ),
          title: Text(
            habit.name,
            style: TextStyle(
              decoration: habit.isCompleted
                  ? TextDecoration.lineThrough
                  : TextDecoration.none,
            ),
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Switch(
                value: habit.isCompleted,
                onChanged: (_) =>
                    Provider.of<HabitsProvider>(context, listen: false)
                        .toggleHabitCompletion(index),
                activeColor: Colors.green,
              ),
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () async {
                  final editedHabitName = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AddHabitScreen(
                        habitName: null, // Passing null to indicate editing
                      ),
                    ),
                  );
                  if (editedHabitName != null && editedHabitName is String) {
                    Provider.of<HabitsProvider>(context, listen: false)
                        .editHabit(index, editedHabitName);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Habit updated.'),
                      ),
                    );
                  }
                },
                tooltip: 'Edit Habit',
              ),
              IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () {
                  Provider.of<HabitsProvider>(context, listen: false)
                      .deleteHabit(index);
                  var habits;
                  _listKey.currentState?.removeItem(
                    index,
                    (context, animation) =>
                        _buildHabitItem(habits[index], index, animation),
                  );
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Habit deleted.'),
                    ),
                  );
                },
                tooltip: 'Delete Habit',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
