// lib/progress_statistics_screen.dart
import 'package:flutter/material.dart';
import 'models/habit.dart';
import 'drawer_screens.dart';

class ProgressStatisticsScreen extends StatelessWidget {
  final List<Habit> habits;

  const ProgressStatisticsScreen({super.key, required this.habits});

  @override
  Widget build(BuildContext context) {
    // Calculate statistics
    int totalHabits = habits.length;
    int completedHabits = habits.where((habit) => habit.isCompleted).length;
    double completionRate =
        totalHabits == 0 ? 0 : (completedHabits / totalHabits) * 100;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Progress & Statistics'),
        centerTitle: true,
      ),
      drawer: const AppDrawer(),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              color: Colors.tealAccent,
              child: ListTile(
                leading: const Icon(Icons.format_list_bulleted, size: 40),
                title: Text(
                  'Total Habits: $totalHabits',
                  style: const TextStyle(fontSize: 20),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              color: Colors.greenAccent,
              child: ListTile(
                leading: const Icon(Icons.check_circle, size: 40),
                title: Text(
                  'Completed Habits: $completedHabits',
                  style: const TextStyle(fontSize: 20),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              color: Colors.orangeAccent,
              child: ListTile(
                leading: const Icon(Icons.percent, size: 40),
                title: Text(
                  'Completion Rate: ${completionRate.toStringAsFixed(1)}%',
                  style: const TextStyle(fontSize: 20),
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Additional statistics or charts can be added here
            Expanded(
              child: Center(
                child: Text(
                  'More statistics coming soon!',
                  style: TextStyle(fontSize: 18, color: Colors.grey[600]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
