// lib/data_backup_sync_screen.dart
import 'package:flutter/material.dart';
import 'drawer_screens.dart';

class DataBackupSyncScreen extends StatelessWidget {
  const DataBackupSyncScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Backup & Sync'),
        centerTitle: true,
      ),
      drawer: const AppDrawer(),
      body: Center(
        child: const Text(
          'Data Backup & Sync coming soon!',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
