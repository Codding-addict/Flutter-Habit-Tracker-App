// lib/journal_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/journal_provider.dart';
import 'drawer_screens.dart';
import 'add_journal_entry_screen.dart';
import 'models/journal_entry.dart';

class JournalScreen extends StatelessWidget {
  const JournalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final journalProvider = Provider.of<JournalProvider>(context);
    final entries = journalProvider.entries;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Journal'),
        centerTitle: true,
      ),
      drawer: const AppDrawer(),
      body: entries.isEmpty
          ? Center(
              child: Text(
                'No journal entries yet!',
                style: TextStyle(fontSize: 18.0, color: Colors.grey[600]),
              ),
            )
          : ListView.builder(
              itemCount: entries.length,
              itemBuilder: (context, index) {
                final entry = entries[index];
                return Card(
                  margin: const EdgeInsets.symmetric(
                      vertical: 4.0, horizontal: 8.0),
                  elevation: 2.0,
                  child: ListTile(
                    title: Text(
                      entry.title,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      entry.content.length > 50
                          ? '${entry.content.substring(0, 50)}...'
                          : entry.content,
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.redAccent),
                      onPressed: () => journalProvider.deleteEntry(index),
                      tooltip: 'Delete Entry',
                    ),
                    onTap: () => showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text(entry.title),
                        content: Text(entry.content),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('Close'),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newEntry = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => const AddJournalEntryScreen()),
          );
          if (newEntry != null && newEntry is JournalEntry) {
            journalProvider.addEntry(newEntry);
          }
        },
        tooltip: 'Add Journal Entry',
        child: const Icon(Icons.add),
      ),
    );
  }
}
