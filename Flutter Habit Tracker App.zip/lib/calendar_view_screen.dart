// lib/calendar_view_screen.dart
// ignore_for_file: unused_import

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';
import 'providers/habits_provider.dart';
import 'models/habit.dart';
import 'drawer_screens.dart';

class CalendarViewScreen extends StatefulWidget {
  final List<Habit> habits;

  const CalendarViewScreen({Key? key, required this.habits}) : super(key: key);

  @override
  _CalendarViewScreenState createState() => _CalendarViewScreenState();
}

class _CalendarViewScreenState extends State<CalendarViewScreen> {
  late Map<DateTime, List<String>> _events;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _events = _generateEvents(widget.habits);
  }

  // Generates a map of events where each key is a date and the value is a list of habit names completed on that date.
  Map<DateTime, List<String>> _generateEvents(List<Habit> habits) {
    Map<DateTime, List<String>> events = {};

    for (var habit in habits) {
      for (var date in habit.completionDates) {
        DateTime eventDate = DateTime(date.year, date.month, date.day);
        if (events[eventDate] == null) {
          events[eventDate] = [habit.name];
        } else {
          if (!events[eventDate]!.contains(habit.name)) {
            events[eventDate]!.add(habit.name);
          }
        }
      }
    }

    return events;
  }

  // Returns the events for a particular day.
  List<String> _getEventsForDay(DateTime day) {
    return _events[DateTime(day.year, day.month, day.day)] ?? [];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calendar View'),
        centerTitle: true,
      ),
      drawer: const AppDrawer(),
      body: Column(
        children: [
          TableCalendar<String>(
            firstDay: DateTime.utc(2000, 1, 1),
            lastDay: DateTime.utc(2100, 12, 31),
            focusedDay: _focusedDay,
            selectedDayPredicate: (day) {
              return isSameDay(_selectedDay, day);
            },
            eventLoader: _getEventsForDay,
            startingDayOfWeek: StartingDayOfWeek.monday,
            calendarStyle: const CalendarStyle(
              // Highlight today
              todayDecoration: BoxDecoration(
                color: Colors.tealAccent,
                shape: BoxShape.circle,
              ),
              selectedDecoration: BoxDecoration(
                color: Colors.teal,
                shape: BoxShape.circle,
              ),
              markerDecoration: BoxDecoration(
                color: Colors.orange,
                shape: BoxShape.circle,
              ),
            ),
            onDaySelected: (selectedDay, focusedDay) {
              if (!isSameDay(_selectedDay, selectedDay)) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                });
              }
            },
            headerStyle: const HeaderStyle(
              formatButtonVisible: false,
              titleCentered: true,
            ),
          ),
          const SizedBox(height: 8.0),
          Expanded(
            child: _selectedDay == null
                ? const Center(
                    child: Text(
                      'Select a day to view completed habits.',
                      style: TextStyle(fontSize: 16.0, color: Colors.grey),
                    ),
                  )
                : _getEventsForDay(_selectedDay!).isEmpty
                    ? Center(
                        child: Text(
                          'No habits completed on ${_selectedDay!.toLocal()}',
                          style: const TextStyle(
                              fontSize: 16.0, color: Colors.grey),
                        ),
                      )
                    : ListView.builder(
                        itemCount: _getEventsForDay(_selectedDay!).length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            leading: const Icon(Icons.check_circle,
                                color: Colors.green),
                            title: Text(_getEventsForDay(_selectedDay!)[index]),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
