// lib/tutorials_help_screen.dart
import 'package:flutter/material.dart';
import 'drawer_screens.dart';

class TutorialsHelpScreen extends StatelessWidget {
  const TutorialsHelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tutorials & Help'),
        centerTitle: true,
      ),
      drawer: const AppDrawer(),
      body: Center(
        child: const Text(
          'Tutorials & Help coming soon!',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
