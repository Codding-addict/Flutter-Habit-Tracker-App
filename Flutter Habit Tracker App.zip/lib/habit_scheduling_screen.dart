// lib/habit_scheduling_screen.dart
import 'package:flutter/material.dart';
import 'drawer_screens.dart';

class HabitSchedulingScreen extends StatelessWidget {
  const HabitSchedulingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Habit Scheduling'),
        centerTitle: true,
      ),
      drawer: const AppDrawer(),
      body: Center(
        child: const Text(
          'Habit Scheduling coming soon!',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
