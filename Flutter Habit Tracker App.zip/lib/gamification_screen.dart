// lib/gamification_screen.dart
import 'package:flutter/material.dart';
import 'drawer_screens.dart';

class GamificationScreen extends StatelessWidget {
  const GamificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gamification'),
        centerTitle: true,
      ),
      drawer: const AppDrawer(),
      body: Center(
        child: const Text(
          'Gamification features coming soon!',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
