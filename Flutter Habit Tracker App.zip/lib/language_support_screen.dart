// lib/language_support_screen.dart
import 'package:flutter/material.dart';
import 'drawer_screens.dart';

class LanguageSupportScreen extends StatelessWidget {
  const LanguageSupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Multi-language Support'),
        centerTitle: true,
      ),
      drawer: const AppDrawer(),
      body: Center(
        child: const Text(
          'Language options coming soon!',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
