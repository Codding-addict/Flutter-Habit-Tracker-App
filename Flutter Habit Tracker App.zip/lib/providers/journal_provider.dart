// lib/providers/journal_provider.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/journal_entry.dart';

class JournalProvider extends ChangeNotifier {
  List<JournalEntry> _entries = [];

  List<JournalEntry> get entries => _entries;

  JournalProvider() {
    _loadEntries();
  }

  // Load journal entries from SharedPreferences
  Future<void> _loadEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final String? entriesData = prefs.getString('journal_entries');
    if (entriesData != null) {
      final List<dynamic> decodedData = jsonDecode(entriesData);
      _entries = decodedData.map((item) => JournalEntry.fromMap(item)).toList();
      notifyListeners();
    }
  }

  // Save journal entries to SharedPreferences
  Future<void> _saveEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final String encodedData =
        jsonEncode(_entries.map((e) => e.toMap()).toList());
    prefs.setString('journal_entries', encodedData);
  }

  // Add a new journal entry
  void addEntry(JournalEntry entry) {
    _entries.insert(0, entry);
    _saveEntries();
    notifyListeners();
  }

  // Delete a journal entry
  void deleteEntry(int index) {
    _entries.removeAt(index);
    _saveEntries();
    notifyListeners();
  }
}
