// lib/providers/habits_provider.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/habit.dart';

class HabitsProvider extends ChangeNotifier {
  List<Habit> _habits = [];

  List<Habit> get habits => _habits;

  HabitsProvider() {
    _loadHabits();
  }

  // Load habits from SharedPreferences
  Future<void> _loadHabits() async {
    final prefs = await SharedPreferences.getInstance();
    final String? habitsData = prefs.getString('habits');
    if (habitsData != null) {
      final List<dynamic> decodedData = jsonDecode(habitsData);
      _habits = decodedData.map((item) => Habit.fromMap(item)).toList();
      notifyListeners();
    }
  }

  // Save habits to SharedPreferences
  Future<void> _saveHabits() async {
    final prefs = await SharedPreferences.getInstance();
    final String encodedData =
        jsonEncode(_habits.map((e) => e.toMap()).toList());
    prefs.setString('habits', encodedData);
  }

  // Add a new habit
  void addHabit(String habitName) {
    _habits.insert(0, Habit(habitName));
    _saveHabits();
    notifyListeners();
  }

  // Edit an existing habit
  void editHabit(int index, String newName) {
    _habits[index].name = newName;
    _saveHabits();
    notifyListeners();
  }

  // Toggle habit completion
  void toggleHabitCompletion(int index) {
    _habits[index].isCompleted = !_habits[index].isCompleted;
    if (_habits[index].isCompleted) {
      DateTime today = DateTime.now();
      if (!_habits[index].completionDates.any((date) =>
          date.year == today.year &&
          date.month == today.month &&
          date.day == today.day)) {
        _habits[index].completionDates.add(today);
      }
    } else {
      _habits[index].completionDates.removeWhere((date) {
        DateTime today = DateTime.now();
        return date.year == today.year &&
            date.month == today.month &&
            date.day == today.day;
      });
    }
    _saveHabits();
    notifyListeners();
  }

  // Delete a habit
  void deleteHabit(int index) {
    _habits.removeAt(index);
    _saveHabits();
    notifyListeners();
  }

  // Delete all completed habits
  void deleteCompletedHabits() {
    _habits.removeWhere((habit) => habit.isCompleted);
    _saveHabits();
    notifyListeners();
  }
}
