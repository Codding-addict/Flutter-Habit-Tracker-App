// lib/drawer_screens.dart
// ignore_for_file: unused_import

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/habits_provider.dart';
import 'models/habit.dart';
import 'main.dart'; // For HomeScreen
import 'progress_statistics_screen.dart';
import 'calendar_view_screen.dart';
import 'notes_screen.dart';
import 'journal_screen.dart';
import 'data_backup_sync_screen.dart';
import 'gamification_screen.dart';
import 'language_support_screen.dart';
import 'accessibility_screen.dart';
import 'habit_scheduling_screen.dart';
import 'tutorials_help_screen.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  Widget _createDrawerItem({
    required BuildContext context,
    required IconData icon,
    required String text,
    required Widget screen,
  }) {
    return ListTile(
      leading: Icon(icon),
      title: Text(text),
      onTap: () {
        Navigator.pop(context); // Close the drawer
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => screen),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final habitsProvider = Provider.of<HabitsProvider>(context, listen: false);
    final habits = habitsProvider.habits;

    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          const DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.teal,
            ),
            child: Text(
              'Habit Tracker Menu',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.home,
            text: 'Home',
            screen: const HomeScreen(),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.show_chart,
            text: 'Progress & Statistics',
            screen: ProgressStatisticsScreen(habits: habits),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.calendar_today,
            text: 'Calendar View',
            screen: CalendarViewScreen(habits: habits),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.note,
            text: 'Notes',
            screen: const NotesScreen(),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.book,
            text: 'Journal',
            screen: const JournalScreen(),
          ),
          const Divider(),
          _createDrawerItem(
            context: context,
            icon: Icons.cloud_sync,
            text: 'Data Backup & Sync',
            screen: const DataBackupSyncScreen(),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.videogame_asset,
            text: 'Gamification',
            screen: const GamificationScreen(),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.language,
            text: 'Multi-language Support',
            screen: const LanguageSupportScreen(),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.accessibility,
            text: 'Accessibility',
            screen: const AccessibilityScreen(),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.schedule,
            text: 'Habit Scheduling',
            screen: const HabitSchedulingScreen(),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.help,
            text: 'Tutorials & Help',
            screen: const TutorialsHelpScreen(),
          ),
        ],
      ),
    );
  }
}
