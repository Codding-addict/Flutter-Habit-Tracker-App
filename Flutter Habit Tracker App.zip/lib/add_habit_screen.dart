// lib/add_habit_screen.dart
import 'package:flutter/material.dart';

class AddHabitScreen extends StatelessWidget {
  final String? habitName;
  AddHabitScreen({super.key, this.habitName});

  final TextEditingController _habitController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    if (habitName != null) {
      _habitController.text = habitName!;
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(habitName != null ? "Edit Habit" : "Add New Habit"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text(
              "Enter Habit Name",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _habitController,
              decoration: InputDecoration(
                labelText: "Habit Name",
                hintText: "e.g., Morning Run",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
                prefixIcon: const Icon(Icons.edit),
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: () {
                final habitName = _habitController.text.trim();
                if (habitName.isNotEmpty) {
                  Navigator.pop(context, habitName);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Please enter a habit name!"),
                    ),
                  );
                }
              },
              icon: Icon(habitName != null ? Icons.save : Icons.add),
              label: Text(
                habitName != null ? "Save Changes" : "Add Habit",
                style: const TextStyle(fontSize: 18),
              ),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
