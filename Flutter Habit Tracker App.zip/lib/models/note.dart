// lib/models/note.dart
class Note {
  String title;
  String content;

  Note({required this.title, required this.content});

  // Convert a Note into a Map
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'content': content,
    };
  }

  // Create a Note from a Map
  factory Note.fromMap(Map<String, dynamic> map) {
    return Note(
      title: map['title'],
      content: map['content'],
    );
  }
}
