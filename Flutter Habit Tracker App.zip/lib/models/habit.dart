// lib/models/habit.dart
class Habit {
  String name;
  bool isCompleted;
  List<DateTime> completionDates;

  Habit(this.name, {this.isCompleted = false, List<DateTime>? completionDates})
      : completionDates = completionDates ?? [];

  // Convert a Habit into a Map
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'isCompleted': isCompleted,
      'completionDates':
          completionDates.map((date) => date.toIso8601String()).toList(),
    };
  }

  // Create a Habit from a Map
  factory Habit.fromMap(Map<String, dynamic> map) {
    return Habit(
      map['name'],
      isCompleted: map['isCompleted'],
      completionDates: (map['completionDates'] as List<dynamic>)
          .map((dateStr) => DateTime.parse(dateStr))
          .toList(),
    );
  }
}
