// lib/models/journal_entry.dart
class JournalEntry {
  String title;
  String content;
  DateTime date;

  JournalEntry(
      {required this.title, required this.content, required this.date});

  // Convert a JournalEntry into a Map
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'content': content,
      'date': date.toIso8601String(),
    };
  }

  // Create a JournalEntry from a Map
  factory JournalEntry.fromMap(Map<String, dynamic> map) {
    return JournalEntry(
      title: map['title'],
      content: map['content'],
      date: DateTime.parse(map['date']),
    );
  }
}
